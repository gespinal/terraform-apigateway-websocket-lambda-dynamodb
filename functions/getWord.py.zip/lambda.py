import os
import json
import urllib3
import boto3
import random

# Connect to apigateway
client = boto3.client('apigatewaymanagementapi', endpoint_url=os.environ['stage_uri'])

# Connect to database
clientDB    = boto3.resource("dynamodb")

def lambda_handler(event, context):

    # Get connectionId from client
    connectionId = event["requestContext"]["connectionId"]

    # Choose table
    table       = clientDB.Table("vocabulary")
    
    # Get list of words from database
    words       = table.scan()

    # Get random word from results
    message     = random.choice(words['Items'])['word']
    
    # Send response to client
    response = client.post_to_connection(ConnectionId=connectionId, Data=message.encode('utf-8'))
